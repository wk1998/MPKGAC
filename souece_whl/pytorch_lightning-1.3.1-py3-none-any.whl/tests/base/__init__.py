"""Models for testing."""

from tests.base.model_template import EvalModelTemplate, GenericEvalModelTemplate  # noqa: F401
