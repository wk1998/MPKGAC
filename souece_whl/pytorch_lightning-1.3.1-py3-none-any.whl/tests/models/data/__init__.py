# this is needed only for mypy==0.800 as it undestands only packages
